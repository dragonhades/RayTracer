#define NUM_THREADS 32
#define PRINT_PROGRESS

#define SSAA
#define REFLECTION
#define REFRACTION
// #define PHOTON_MAPPING
#define MAX_SHADE_RECURSION 6

// #define DRAW_BBOX
#define LIGHT_TURN_ON
